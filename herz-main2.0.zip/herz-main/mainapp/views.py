from django.shortcuts import render
import pandas as pd
import tensorflow as tf
from django.http import HttpResponseRedirect



def index(request):
    if request.method == 'POST':
        r1 = int(request.POST['q1'])
        r2 = int(request.POST['q2'])
        r3 = int(request.POST['q3'])
        r4 = float(request.POST['q4'])
        r5 = float(request.POST['q5'])
        r6 = float(request.POST['q6'])
        r7 = float(request.POST['q7'])
        r8 = float(request.POST['q8'])
        r9 = float(request.POST['q9'])
        r10 = float(request.POST['q10'])
        r11 = float(request.POST['q11'])
        r12 = float(request.POST['q12'])
        r13 = float(request.POST['q13'])
        dataset = pd.read_csv('Heart Attack Data Set (1).csv')
        X = dataset.iloc[:, :-1].values
        y = dataset.iloc[:, -1].values

        from sklearn.model_selection import train_test_split
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3, random_state = 0)

        from sklearn.preprocessing import StandardScaler
        sc = StandardScaler()
        X_train = sc.fit_transform(X_train)
        X_test = sc.transform(X_test)

        ann = tf.keras.models.Sequential()
        ann.add(tf.keras.layers.Dense(units=7, activation='relu'))
        ann.add(tf.keras.layers.Dense(units=2, activation='relu'))
        ann.add(tf.keras.layers.Dense(units=1, activation='sigmoid'))

        ann.compile(optimizer = 'adam', loss = 'binary_crossentropy', metrics = ['accuracy'])
        ann.fit(X_train, y_train, batch_size = 32, epochs = 100)
        result = ann.predict(sc.transform([[r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13]])) > 0.5
        if result == True:
            show = "High Risk"
        elif result == False:
            show = "Low Risk"
        return render(request, "form/form.html",{"priyansh": show})
    return render(request, "mainapp/homepage.html")

def form(request):
    
    return render(request, "form/form.html")
